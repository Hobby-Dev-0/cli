class FFmpegReturnCodeError(Exception):
    pass
