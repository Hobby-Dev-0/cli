class ser(object):
  HC= None
  HU= None
  HA= None
  HO= None
  HAT = None
